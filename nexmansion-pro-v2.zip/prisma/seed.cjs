
/* eslint-disable */
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();
async function main(){
  await prisma.property.createMany({ data: [
    { title:'Luxury Villa in Cannes', description:'Sea-view, infinity pool', location:'Cannes, France', pricePerNight:1200 },
    { title:'Chalet in the Alps', description:'Fireplace, ski-in/ski-out', location:'Chamonix, France', pricePerNight:600 },
    { title:'Apartment in Paris', description:'Eiffel tower view', location:'Paris, France', pricePerNight:400 },
  ]});
  console.log('Seeded.');
}
main().catch(e=>{console.error(e);process.exit(1)}).finally(async()=>{await prisma.$disconnect()});
