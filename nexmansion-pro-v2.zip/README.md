
# NexMansion Pro v2 (Local)

Next.js app with server-side Concierge calling AIMLAPI (OpenAI-compatible) to avoid browser CORS. Includes iCal export and optional Stripe demo checkout.

## Setup
```bash
npm install
cp .env.example .env
# Fill AIMLAPI_* vars (and Stripe if needed)
npm run dev
```

Open http://localhost:3000 and use the form to query /api/concierge.
