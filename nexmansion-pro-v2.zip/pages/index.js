
export default function Home(){
  return (
    <div style={{fontFamily:'ui-sans-serif,system-ui',padding:'24px',lineHeight:1.4}}>
      <h1>NexMansion — Local Demo</h1>
      <p>Concierge IA via server-side (AIMLAPI/OpenAI). No browser CORS issues.</p>
      <form onSubmit={async (e)=>{
        e.preventDefault();
        const prompt = e.currentTarget.prompt.value;
        const out = document.getElementById('out');
        out.textContent = 'Thinking...';
        const res = await fetch('/api/concierge',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt})});
        const data = await res.json();
        out.textContent = data.reply || data.error || 'No reply';
      }}>
        <textarea name='prompt' rows={4} style={{width:'100%',padding:'8px'}} defaultValue={'I want a romantic weekend in Paris with spa.'} />
        <div style={{marginTop:'8px'}}><button>Ask Concierge</button></div>
      </form>
      <h3 style={{marginTop:'24px'}}>Utilities</h3>
      <ul>
        <li><a href='/api/ical/export' target='_blank'>Export iCal (bookings)</a></li>
      </ul>
      <pre id='out' style={{marginTop:'16px',whiteSpace:'pre-wrap',background:'#f5f5f5',padding:'12px'}}></pre>
    </div>
  )
}
