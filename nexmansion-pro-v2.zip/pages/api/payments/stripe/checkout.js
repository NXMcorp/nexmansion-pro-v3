
import Stripe from 'stripe'
export default async function handler(req, res){
  if(req.method!=='POST') return res.status(405).json({ error:'Method not allowed' })
  if(!process.env.STRIPE_SECRET_KEY) return res.status(500).json({ error:'Missing STRIPE_SECRET_KEY' })
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY)
  const base = process.env.NEXT_PUBLIC_BASE_URL || 'http://localhost:3000'
  const total = 400 // demo
  const session = await stripe.checkout.sessions.create({
    mode:'payment',
    success_url: `${base}/api/payments/stripe/success`,
    cancel_url: `${base}/api/payments/stripe/cancel`,
    line_items:[{ price_data:{ currency:'eur', unit_amount: total*100, product_data:{ name:'NexMansion Demo Stay' } }, quantity:1 }]
  })
  res.status(200).json({ url: session.url })
}
