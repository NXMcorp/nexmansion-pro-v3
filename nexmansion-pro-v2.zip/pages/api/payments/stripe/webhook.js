
import Stripe from 'stripe'
export const config = { api: { bodyParser: false } }
function buffer(req) {
  return new Promise((resolve, reject) => {
    const chunks = []
    req.on('data', (c) => chunks.push(c))
    req.on('end', () => resolve(Buffer.concat(chunks)))
    req.on('error', reject)
  })
}
export default async function handler(req, res){
  const sig = req.headers['stripe-signature']
  const wh = process.env.STRIPE_WEBHOOK_SECRET
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '')
  const raw = await buffer(req)
  let event
  try { event = stripe.webhooks.constructEvent(raw, sig, wh) }
  catch (e) { return res.status(400).json({ error:'Webhook error: '+e.message }) }
  // handle events (demo: just log)
  console.log('Stripe event', event.type)
  res.json({ received:true })
}
