
import ical from 'ical-generator'

export default async function handler(req, res){
  const cal = ical({ name: 'NexMansion Bookings' })
  // demo entries; in a real app, fetch from DB
  const now = new Date()
  cal.createEvent({ start: now, end: new Date(now.getTime()+86400000), summary: 'Booking: Demo Property', description: 'Guests: 2 · Total: €400' })
  res.setHeader('Content-Type','text/calendar; charset=utf-8')
  res.send(cal.toString())
}
