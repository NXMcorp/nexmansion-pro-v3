
export default async function handler(req, res){
  if(req.method !== 'POST') return res.status(405).json({ error:'Method not allowed' });
  const { prompt } = req.body || {};
  if(!prompt) return res.status(400).json({ error:'Missing prompt' });

  const aimlBase = process.env.AIMLAPI_BASE_URL;
  const aimlKey = process.env.AIMLAPI_API_KEY;
  const aimlModel = process.env.AIMLAPI_MODEL || 'gpt-4o';

  // helper to call OpenAI-compatible endpoint
  async function callCompatible(baseUrl, apiKey, model){
    const url = baseUrl.replace(/\/$/, '') + '/chat/completions';
    const r = await fetch(url, {
      method:'POST',
      headers:{ 'Content-Type':'application/json', 'Authorization':`Bearer ${apiKey}` },
      body: JSON.stringify({
        model,
        messages: [
          { role:'system', content:'You are a luxury travel concierge for NexMansion.'},
          { role:'user', content: prompt}
        ],
        temperature: 0.7
      })
    });
    if(!r.ok) throw new Error('HTTP '+r.status);
    const data = await r.json();
    return data?.choices?.[0]?.message?.content || data?.output || data?.text || '(no content)';
  }

  try {
    if(aimlBase && aimlKey){
      const text = await callCompatible(aimlBase, aimlKey, aimlModel);
      return res.status(200).json({ reply: text, provider:'aimlapi' });
    }
  } catch(e){
    console.error('AIMLAPI error:', e);
  }

  try {
    if(process.env.OPENAI_API_KEY){
      const text = await callCompatible('https://api.openai.com/v1', process.env.OPENAI_API_KEY, 'gpt-4o-mini');
      return res.status(200).json({ reply: text, provider:'openai' });
    }
  } catch(e){
    console.error('OpenAI error:', e);
  }

  // Demo fallback
  const ideas = [
    "Stay at the Paris Apartment with balcony, book a 2h spa at Bain de la Opera, dinner at Le Jules Verne.",
    "Alpine escape: Chamonix chalet, morning ski + private fondue chef, stargazing by the fireplace.",
    "Cannes villa sunset: yacht mini-cruise, private chef tasting menu, massage on the terrace."
  ];
  const demo = ideas[Math.floor(Math.random()*ideas.length)] + ' (demo)';
  return res.status(200).json({ reply: demo, provider:'demo' });
}
